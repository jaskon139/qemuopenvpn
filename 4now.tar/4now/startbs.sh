curl https://v2rytype.herokuapp.com/
../kcpexe/client_linux_386 -r "10.241.183.229:9999" -l ":5388" -mode fast2 &
../ssexe/v2ray-v3.31.1-linux-32/v2ray -config ./clientconfig.json &
sleep 15m
./startbs.sh
